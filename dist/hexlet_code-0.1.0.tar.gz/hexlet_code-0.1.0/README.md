### Hexlet tests and linter status:
[![Actions Status](https://github.com/Nik-NN/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Nik-NN/python-project-49/actions)
<a href="https://codeclimate.com/github/Nik-NN/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/6613a34a5986df38d122/maintainability" /></a>
brain_even: https://asciinema.org/a/hL2fFMKi2MSlhTNu7XqOAAAu9
brain_calc: https://asciinema.org/a/OwUHkDOFf2zyqgSPcoZrNGdzv